'use strict';

const $app = document.getElementById('app');
let me = null;          // utilisateur connecté
let needsSetup = false; // aucun compte encore créé
let navDepth = 0;       // pour le bouton « retour »
let currentOwnList = null; // liste ouverte (si elle m'appartient) → le bouton + y ajoute directement

// ============ Icônes ============
const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8"/><path d="M18.5 14.4A6.5 6.5 0 0 1 21.5 20"/>',
  gift: '<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M19 12v8a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-8"/><path d="M7.5 8a2.5 2.5 0 0 1 0-5C10 3 12 8 12 8s2-5 4.5-5a2.5 2.5 0 0 1 0 5"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  back: '<path d="M19 12H5M12 19l-7-7 7-7"/>',
  arrow: '<path d="M7 17 17 7M8 7h9v9"/>',
  chevron: '<path d="m9 18 6-6-6-6"/>',
  external: '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"/>',
  edit: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M5 7l1 13a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1l1-13M9 7V4h6v3"/>',
  check: '<path d="m5 12 5 5 9-10"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  camera: '<path d="M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/>',
  logout: '<path d="M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4M10 17l5-5-5-5M15 12H3"/>',
  eyeOff: '<path d="M3 3l18 18M10.6 6.1A9.8 9.8 0 0 1 12 6c6 0 9.5 6 9.5 6a17 17 0 0 1-3 3.6M6.6 6.6A17 17 0 0 0 2.5 12S6 18 12 18a9.4 9.4 0 0 0 4.4-1.1M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
  copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  bookmark: '<path d="M6 3h12v18l-6-4-6 4z"/>',
  lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>',
};
const icon = (n, cls = '') => `<svg class="icon ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ''}</svg>`;

// ============ Utilitaires ============
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const h = (html) => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };
// « de Marina » / « d'Alice »
const deName = (name) => (/^[aeiouyhàâäéèêëîïôöûü]/i.test(name || '') ? 'd\'' : 'de ') + esc(name || '');
const plural =(n, word, pl = word + 's') => `${n} ${n > 1 ? pl : word}`;
const store = {
  get: (k) => { try { return localStorage.getItem(k) || ''; } catch { return ''; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch { /* stockage indisponible */ } },
};

async function api(method, url, body) {
  const opts = { method, headers: {} };
  if (body instanceof Blob) { opts.body = body; opts.headers['Content-Type'] = body.type; }
  else if (body !== undefined) { opts.body = JSON.stringify(body); opts.headers['Content-Type'] = 'application/json'; }
  const res = await fetch(url, opts);
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && me && !url.startsWith('/api/login')) { me = null; route(); }
  if (!res.ok) throw Object.assign(new Error(data.error || 'Erreur ' + res.status), { status: res.status });
  return data;
}

let toastTimer;
function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}

async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch {
    const i = h('<textarea style="position:fixed;opacity:0"></textarea>'); i.value = text;
    document.body.append(i); i.select(); document.execCommand('copy'); i.remove();
  }
  toast('Lien copié !');
}

// Couleurs d'avatar & teintes de cartes
const AVATAR_COLORS = ['#ffd1bf', '#c6ebd7', '#dcd2fb', '#cde0fb', '#ffe6a3', '#fccfdd', '#d6efc4'];
function hashStr(s) { let x = 0; for (const c of String(s)) x = (x * 31 + c.codePointAt(0)) >>> 0; return x; }
function initials(name) {
  const parts = String(name || '?').trim().split(/\s+/);
  return ((parts[0]?.[0] || '?') + (parts[1]?.[0] || '')).toUpperCase();
}
const avatar = (name, cls = '') => `<span class="avatar ${cls}" style="background:${AVATAR_COLORS[hashStr(name) % AVATAR_COLORS.length]}" aria-hidden="true">${esc(initials(name))}</span>`;
const tint = (id) => `--tint: var(--tint-${Number(id) % 6})`;

// Dates
const DAY = 86400000;
const parseDate = (d) => new Date(d + 'T00:00:00');
function daysUntil(d) { const t = new Date(); t.setHours(0, 0, 0, 0); return Math.round((parseDate(d) - t) / DAY); }
function whenLabel(d) {
  const n = daysUntil(d);
  if (n === 0) return 'Aujourd\'hui !';
  if (n === 1) return 'Demain';
  if (n > 1) return `Dans ${n} jours`;
  return 'Passé';
}
const fmtDate = (d) => parseDate(d).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: parseDate(d).getFullYear() !== new Date().getFullYear() ? 'numeric' : undefined });
const monthShort = (d) => parseDate(d).toLocaleDateString('fr-FR', { month: 'short' }).replace('.', '');

const hostOf = (u) => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return ''; } };
const isUpload = (src) => String(src || '').startsWith('/uploads/');
window.imgFail = (img) => { img.outerHTML = `<span class="placeholder">${illus('gift')}</span>`; };
const imgTag = (src, alt = '') => `<img src="${esc(src)}" alt="${esc(alt)}" loading="lazy" referrerpolicy="no-referrer" class="${isUpload(src) ? 'photo' : ''}" onerror="imgFail(this)">`;

// Réduit les grosses photos avant envoi (max 1600 px)
async function shrinkImage(file) {
  if (file.type === 'image/gif' || file.size < 1_200_000) return file;
  try {
    const bmp = await createImageBitmap(file);
    const scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(bmp.width * scale); canvas.height = Math.round(bmp.height * scale);
    canvas.getContext('2d').drawImage(bmp, 0, 0, canvas.width, canvas.height);
    return await new Promise((ok) => canvas.toBlob((b) => ok(b || file), 'image/jpeg', 0.85));
  } catch { return file; }
}

// ============ Navigation ============
function go(path) { navDepth++; history.pushState(null, '', path); route(); }
function back(fallback = '/') { if (navDepth > 0) { navDepth--; history.back(); } else { history.replaceState(null, '', fallback); route(); } }
document.addEventListener('click', (e) => {
  const a = e.target.closest('a[data-link]');
  if (a && !e.metaKey && !e.ctrlKey && !e.shiftKey && e.button === 0) { e.preventDefault(); go(a.getAttribute('href')); }
});
window.addEventListener('popstate', () => { navDepth = Math.max(0, navDepth - 1); route(); });

const TABS = [
  ['/', 'home', 'Accueil'],
  ['/famille', 'users', 'Famille'],
  ['/reserves', 'gift', 'Réservés'],
  ['/profil', 'user', 'Profil'],
];
function activeTab(path) {
  if (path.startsWith('/famille')) return '/famille';
  if (path.startsWith('/reserves')) return '/reserves';
  if (path.startsWith('/profil')) return '/profil';
  return '/';
}
function renderChrome(mode) {
  const topbar = document.getElementById('topbar');
  const tabbar = document.getElementById('tabbar');
  document.body.classList.toggle('no-chrome', mode === 'none');
  document.body.classList.toggle('guest', mode === 'guest');
  topbar.hidden = mode === 'none';
  tabbar.hidden = mode !== 'app';
  const right = document.getElementById('topbar-right');
  const nav = document.getElementById('topnav');
  if (mode !== 'app') {
    nav.innerHTML = '';
    right.innerHTML = mode === 'guest' ? '<a class="btn sm" href="/" data-link>Se connecter</a>' : '';
    return;
  }
  const act = activeTab(location.pathname);
  const link = ([href, ic, label]) => `<a href="${href}" data-link class="${act === href ? 'active' : ''}" ${act === href ? 'aria-current="page"' : ''}>`;
  nav.innerHTML = TABS.map((t) => `${link(t)}${icon(t[1])}${t[2]}</a>`).join('');
  tabbar.innerHTML = TABS.slice(0, 2).map((t) => `${link(t)}<span class="tab-ico">${icon(t[1])}</span>${t[2]}</a>`).join('')
    + `<button class="fab" id="fab" aria-label="Ajouter une idée">${icon('plus')}</button>`
    + TABS.slice(2).map((t) => `${link(t)}<span class="tab-ico">${icon(t[1])}</span>${t[2]}</a>`).join('');
  right.innerHTML = `<button class="btn primary sm desk-only" id="fab-desk">${icon('plus')} Ajouter une idée</button>
    <a href="/profil" data-link title="Mon profil">${avatar(me.name)}</a>`;
  document.getElementById('fab').onclick = () => openAddIdea(currentOwnList);
  document.getElementById('fab-desk').onclick = () => openAddIdea(currentOwnList);
}

async function route() {
  const path = location.pathname;
  closeSheet();
  currentOwnList = null;
  window.scrollTo(0, 0);
  try {
    const r = await api('GET', '/api/me');
    me = r.user; needsSetup = r.needsSetup;
    let m;
    if ((m = path.match(/^\/l\/([\w-]+)/))) {
      if (me) { const s = await api('GET', `/api/share/${m[1]}`); history.replaceState(null, '', `/list/${s.id}`); return route(); }
      return await renderShare(m[1]);
    }
    if ((m = path.match(/^\/join\/([\w-]+)/))) {
      if (me) { history.replaceState(null, '', '/'); return route(); }
      return await renderAuth('signup', m[1]);
    }
    if (!me) return await renderAuth(needsSetup ? 'signup' : 'login');
    renderChrome('app');
    $app.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
    if (path === '/') return await renderHome();
    if ((m = path.match(/^\/list\/(\d+)/))) return await renderList(Number(m[1]));
    if (path === '/famille') return await renderFamily();
    if ((m = path.match(/^\/famille\/(\d+)/))) return await renderMember(Number(m[1]));
    if (path === '/reserves') return await renderReserved();
    if (path === '/profil') return renderProfile();
    if (path === '/add') return await renderQuickAdd();
    $app.innerHTML = emptyState('search', 'Page introuvable', '<a class="btn primary" href="/" data-link>Retour à l\'accueil</a>');
  } catch (e) {
    $app.innerHTML = emptyState('search', esc(e.message), '<a class="btn" href="/" data-link>Retour à l\'accueil</a>');
  }
}
const emptyState = (art, text, extra = '') => `<div class="empty"><div class="big">${illus(art, 'xl')}</div><p>${text}</p>${extra}</div>`;

// ============ Fenêtres (sheets) ============
let sheetEl = null;
function openSheet({ title = '', wide = false } = {}) {
  closeSheet();
  const backdrop = h(`<div class="sheet-backdrop">
    <div class="sheet ${wide ? 'wide' : ''}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="grabber"></div>
      <div class="sheet-head"><h2>${esc(title)}</h2><button class="icon-btn sm" data-close aria-label="Fermer">${icon('x')}</button></div>
      <div class="sheet-body"></div>
    </div></div>`);
  backdrop.addEventListener('mousedown', (e) => { if (e.target === backdrop) closeSheet(); });
  backdrop.querySelector('[data-close]').onclick = closeSheet;
  document.body.append(backdrop);
  document.body.style.overflow = 'hidden';
  sheetEl = backdrop;
  return { body: backdrop.querySelector('.sheet-body'), close: closeSheet, el: backdrop };
}
function closeSheet() {
  if (!sheetEl) return;
  sheetEl.remove(); sheetEl = null;
  document.body.style.overflow = '';
}
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeSheet(); });

function confirmSheet({ title, text, ok = 'Confirmer', danger = false }) {
  return new Promise((resolve) => {
    const s = openSheet({ title });
    s.body.append(h(`<div class="form"><p class="muted">${text}</p>
      <div style="display:flex;gap:10px;justify-content:flex-end;flex-wrap:wrap">
        <button class="btn" data-no>Annuler</button>
        <button class="btn ${danger ? 'danger' : 'primary'}" data-yes>${esc(ok)}</button>
      </div></div>`));
    s.body.querySelector('[data-no]').onclick = () => { closeSheet(); resolve(false); };
    s.body.querySelector('[data-yes]').onclick = () => { closeSheet(); resolve(true); };
    s.el.querySelector('[data-close]').addEventListener('click', () => resolve(false));
  });
}

// ============ Connexion / inscription ============
async function renderAuth(mode, invite) {
  renderChrome('none');
  const signup = mode === 'signup';
  document.title = (signup ? 'Créer un compte' : 'Connexion') + ' – Wishlist';
  if (signup && invite && !needsSetup) {
    const { valid } = await api('GET', `/api/invite/${encodeURIComponent(invite)}`);
    if (!valid) {
      $app.innerHTML = `<div class="auth"><div class="auth-box">${emptyState('mail', 'Ce lien d\'invitation n\'est plus valable.<br>Demandez-en un nouveau à un membre de la famille.', '<a class="btn" href="/" data-link>J\'ai déjà un compte</a>')}</div></div>`;
      return;
    }
  }
  const lead = signup
    ? (needsSetup ? 'Créez le premier compte de la famille. Vous pourrez ensuite inviter les autres.' : 'Vous êtes invité·e ! Choisissez simplement un nom et un mot de passe.')
    : 'Connectez-vous pour voir et réserver les idées de cadeaux de la famille.';
  $app.innerHTML = `
    <div class="auth"><div class="auth-box">
      <div class="auth-visual" aria-hidden="true">
        <div class="blob"></div><div class="gift">${illus('gift')}</div>
        <div class="float f1">${illus('heart')}</div><div class="float f2">${illus('sparkles')}</div>
        <div class="bubble b1">${illus('cake', 'sm')} Anniversaire de Léa · dans 5 jours</div>
        <div class="bubble b2">${illus('check', 'sm')} Réservé par Papi</div>
      </div>
      <div><h1>Nos envies,<br>en <span class="hl">famille</span></h1><p class="lead">${lead}</p></div>
      <form class="card form" id="auth-form">
        <label class="field"><span>Nom</span>
          <input type="text" name="name" autocomplete="username" required maxlength="40" placeholder="ex. Marina"></label>
        <label class="field"><span>Mot de passe</span>
          <input type="password" name="password" autocomplete="${signup ? 'new-password' : 'current-password'}" required ${signup ? 'minlength="6" placeholder="6 caractères minimum"' : ''}></label>
        <p class="form-msg err" role="alert"></p>
        <button class="btn primary block">${signup ? 'Créer mon compte' : 'Se connecter'}</button>
        <p class="small muted" style="text-align:center">Vous restez connecté·e pendant 30 jours sur cet appareil.</p>
      </form>
      ${signup && !needsSetup ? '<p class="switch">Déjà un compte ? <a class="link" href="/" data-link>Se connecter</a></p>' : ''}
      ${!signup ? '<p class="switch">Pas encore de compte ? Demandez un lien d\'invitation à un membre de la famille.</p>' : ''}
    </div></div>`;
  const f = document.getElementById('auth-form');
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = f.querySelector('button'); btn.disabled = true;
    try {
      await api('POST', signup ? '/api/signup' : '/api/login', { name: f.name.value, password: f.password.value, invite });
      if (location.pathname.startsWith('/join')) history.replaceState(null, '', '/');
      if (signup) toast(`Bienvenue ${f.name.value.trim()} !`);
      route();
    } catch (err) { f.querySelector('.form-msg').textContent = err.message; btn.disabled = false; }
  });
}

// ============ Cartes réutilisables ============
function listCard(l, showOwner = false) {
  const progress = l.chosen_count != null && l.item_count > 0 && !l.is_owner;
  return `
    <a class="list-card" style="${tint(l.id)}" href="/list/${l.id}" data-link>
      <span class="go">${icon('arrow')}</span>
      <span class="emoji">${listIcon(l.emoji)}</span>
      <h3>${esc(l.title)}</h3>
      <div class="meta">
        <span class="pill">${plural(l.item_count, 'idée')}</span>
        ${l.event_date ? `<span class="pill">${icon('calendar')} ${esc(fmtDate(l.event_date))}</span>` : ''}
        ${l.is_owner && l.surprise ? `<span class="pill">${icon('eyeOff')} Surprise</span>` : ''}
      </div>
      <div class="foot">
        ${showOwner ? `<span class="owner">${avatar(l.owner_name || '?')}${esc(l.owner_name || '')}</span>` : '<span></span>'}
        ${progress ? `<span class="small" style="display:flex;align-items:center;gap:8px;font-weight:600">${l.chosen_count}/${l.item_count}
          <span class="progress" style="width:60px"><span style="width:${Math.round(100 * l.chosen_count / l.item_count)}%"></span></span></span>` : ''}
      </div>
    </a>`;
}
function eventCard(l) {
  return `
    <a class="event-card" href="/list/${l.id}" data-link>
      <div class="top"><span class="emoji">${listIcon(l.emoji)}</span>
        <span class="date-badge"><small>${esc(monthShort(l.event_date))}</small><b>${parseDate(l.event_date).getDate()}</b></span></div>
      <h3>${esc(l.title)}</h3>
      <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
        <span class="pill">${l.is_owner ? 'Ma liste' : esc(l.owner_name)}</span>
        ${l.chosen_count != null && !l.is_owner ? `<span class="pill accent">${icon('gift')} ${l.chosen_count}/${l.item_count}</span>` : ''}
      </div>
      <span class="when">${whenLabel(l.event_date)}</span>
    </a>`;
}

// ============ Accueil ============
const SHOPS = [
  ['Google Shopping', (q) => `https://www.google.com/search?tbm=shop&q=${q}`],
  ['Amazon', (q) => `https://www.amazon.fr/s?k=${q}`],
  ['Fnac', (q) => `https://www.fnac.com/SearchResult/ResultList.aspx?Search=${q}`],
  ['Leboncoin', (q) => `https://www.leboncoin.fr/recherche?text=${q}`],
  ['Etsy', (q) => `https://www.etsy.com/fr/search?q=${q}`],
];

async function renderHome() {
  document.title = 'Accueil – Wishlist';
  const lists = await api('GET', '/api/lists');
  const mine = lists.filter((l) => l.is_owner);
  const others = lists.filter((l) => !l.is_owner);
  const upcoming = lists.filter((l) => l.event_date && daysUntil(l.event_date) >= 0)
    .sort((a, b) => a.event_date.localeCompare(b.event_date)).slice(0, 12);
  const hour = new Date().getHours();
  const greet = hour >= 18 || hour < 5 ? 'Bonsoir' : 'Bonjour';

  $app.innerHTML = `
    <div class="stack">
      <div class="hello">
        <div><h1>${greet}, ${esc(me.name)}</h1><p class="muted">Faisons plaisir à quelqu'un aujourd'hui.</p></div>
      </div>

      <div>
        <form class="searchbar" id="search" role="search">${icon('search')}
          <input type="search" name="q" placeholder="Rechercher une idée de cadeau…" autocomplete="off" aria-label="Rechercher"></form>
        <div id="search-out"></div>
      </div>

      ${!mine.length ? `
        <div class="hero-banner">
          <h2>Planifiez. Partagez.<br>Offrez avec amour.</h2>
          <p>Créez votre première liste et ajoutez-y vos envies : un lien, une photo ou juste un titre.</p>
          <span class="big-emoji" aria-hidden="true">${illus('gift')}</span>
          <button class="btn primary sm" style="margin-top:14px" id="hero-new">${icon('plus')} Créer une liste</button>
        </div>` : ''}

      ${upcoming.length ? `
        <section>
          <div class="section-head"><h2>Événements à venir</h2></div>
          <div class="hscroll">${upcoming.map(eventCard).join('')}</div>
        </section>` : ''}

      <section>
        <div class="section-head"><h2>Mes listes</h2><button class="link" id="new-list">+ Nouvelle liste</button></div>
        <div class="list-grid">
          ${mine.map((l) => listCard(l)).join('')}
          <button class="new-card" id="new-list-card"><span class="icon-btn">${icon('plus')}</span>Nouvelle liste</button>
        </div>
      </section>

      <section>
        <div class="section-head"><h2>Listes de la famille</h2>${others.length ? '<a href="/famille" data-link>Voir la famille</a>' : ''}</div>
        ${others.length ? `<div class="list-grid">${others.map((l) => listCard(l, true)).join('')}</div>` : `
          <div class="card" style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
            <span class="art-md">${illus('family')}</span>
            <div style="flex:1;min-width:200px"><h3>Invitez la famille</h3><p class="muted small">Envoyez-leur le lien d'invitation pour qu'ils créent leurs listes.</p></div>
            <a class="btn soft" href="/famille" data-link>Inviter</a>
          </div>`}
      </section>
    </div>`;

  for (const id of ['new-list', 'new-list-card', 'hero-new']) document.getElementById(id)?.addEventListener('click', () => openListForm());

  // Recherche (au fil de la frappe)
  const sf = document.getElementById('search');
  const out = document.getElementById('search-out');
  let timer;
  const run = async () => {
    const term = sf.q.value.trim();
    if (!term) { out.innerHTML = ''; return; }
    const enc = encodeURIComponent(term);
    const results = await api('GET', '/api/search?q=' + enc);
    if (sf.q.value.trim() !== term) return;
    out.innerHTML = `
      <div class="card" style="margin-top:12px;display:grid;gap:14px">
        ${results.length ? `<div class="rows">${results.map((i) => `
          <a class="row-item" href="/list/${i.list_id}" data-link>
            <span class="mini">${i.image ? imgTag(i.image) : illus('gift')}</span>
            <div><h3>${esc(i.title)}</h3>
              <p class="small muted">${esc(i.list_title)} · ${i.owner_id === me.id ? 'ma liste' : esc(i.owner_name)}${i.price ? ' · ' + esc(i.price) : ''}</p></div>
            ${i.chosen ? `<span class="pill ok">${icon('check')} Réservé</span>` : ''}
          </a>`).join('')}</div>` : '<p class="muted">Aucune idée trouvée dans les listes de la famille.</p>'}
        <div>
          <p class="small muted" style="margin-bottom:10px">Chercher « ${esc(term)} » sur internet, puis coller le lien dans une liste :</p>
          <div class="shop-links">${SHOPS.map(([n, u]) => `<a class="btn sm" href="${u(enc)}" target="_blank" rel="noopener">${esc(n)} ${icon('external')}</a>`).join('')}</div>
        </div>
      </div>`;
  };
  sf.addEventListener('submit', (e) => { e.preventDefault(); run(); });
  sf.q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(run, 300); });
}

// ============ Formulaire de liste ============
function openListForm(list = null) {
  const s = openSheet({ title: list ? 'Modifier la liste' : 'Nouvelle liste' });
  let emoji = LIST_ICONS.includes(list?.emoji) ? list.emoji : 'gift';
  const f = h(`
    <form class="form">
      <div class="field"><span>Icône</span>
        <div class="emoji-pick">${LIST_ICONS.map((e) => `<button type="button" data-e="${e}" class="${e === emoji ? 'on' : ''}" title="${LIST_ICON_LABELS[e]}" aria-label="${LIST_ICON_LABELS[e]}">${illus(e)}</button>`).join('')}</div></div>
      <label class="field"><span>Nom de la liste *</span>
        <input type="text" name="title" maxlength="120" required placeholder="ex. Noël 2026" value="${esc(list?.title)}"></label>
      <label class="field"><span>Date de l'événement (facultatif)</span>
        <input type="date" name="event_date" value="${esc(list?.event_date || '')}"></label>
      <label class="field"><span>Description (facultatif)</span>
        <textarea name="description" maxlength="1000" placeholder="Taille de vêtements, préférences…">${esc(list?.description)}</textarea></label>
      <label class="toggle card" style="padding:14px 16px">
        <span><strong>Mode surprise</strong><br><span class="small muted">Je ne vois pas quelles idées ont été réservées.</span></span>
        <input type="checkbox" name="surprise" ${list ? (list.surprise ? 'checked' : '') : 'checked'}></label>
      <p class="form-msg err"></p>
      <button class="btn primary block">${list ? 'Enregistrer' : 'Créer la liste'}</button>
      ${list ? `<button type="button" class="btn ghost danger block" data-del>${icon('trash')} Supprimer la liste</button>` : ''}
    </form>`);
  f.querySelector('.emoji-pick').addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    emoji = b.dataset.e;
    f.querySelectorAll('.emoji-pick button').forEach((x) => x.classList.toggle('on', x === b));
  });
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = { title: f.title.value, event_date: f.event_date.value || null, description: f.description.value, surprise: f.surprise.checked, emoji };
    try {
      const saved = list ? await api('PATCH', `/api/lists/${list.id}`, data) : await api('POST', '/api/lists', data);
      closeSheet();
      toast(list ? 'Liste modifiée' : 'Liste créée');
      if (list) route(); else go(`/list/${saved.id}`);
    } catch (err) { f.querySelector('.form-msg').textContent = err.message; }
  });
  f.querySelector('[data-del]')?.addEventListener('click', async () => {
    if (!(await confirmSheet({ title: 'Supprimer la liste ?', text: `« ${esc(list.title)} » et toutes ses idées seront supprimées définitivement.`, ok: 'Supprimer', danger: true }))) return;
    await api('DELETE', `/api/lists/${list.id}`);
    toast('Liste supprimée');
    history.replaceState(null, '', '/'); route();
  });
  s.body.append(f);
  if (!list) setTimeout(() => f.title.focus(), 50);
}

// ============ Formulaire d'idée ============
function itemForm(initial = {}, { submitLabel = 'Ajouter l\'idée', onSave } = {}) {
  const state = { image: initial.image || '', auto: {} };
  const form = h(`
    <form class="form">
      <div class="field"><span>Lien du produit (facultatif)</span>
        <div class="url-row">
          <input type="url" name="url" placeholder="Coller un lien https://…" value="${esc(initial.url)}">
          <button type="button" class="btn soft" data-fetch>Récupérer</button>
        </div></div>
      <div class="photo-pick">
        <div class="pv"></div>
        <div style="display:grid;gap:6px">
          <div class="btns">
            <label class="btn sm">${icon('camera')} Photo<input type="file" accept="image/*" hidden></label>
            <button type="button" class="btn sm ghost" data-remove-photo>Retirer</button>
          </div>
          <span class="small muted">Facultatif : une photo ou celle du lien</span>
        </div>
      </div>
      <label class="field"><span>Titre *</span>
        <input type="text" name="title" maxlength="300" required placeholder="ex. Parfum Candy Cherry" value="${esc(initial.title)}"></label>
      <label class="field"><span>Prix (facultatif)</span>
        <input type="text" name="price" maxlength="50" placeholder="ex. 24,99 €" value="${esc(initial.price)}"></label>
      <label class="field"><span>Note (facultatif)</span>
        <textarea name="note" maxlength="1000" placeholder="Taille, couleur, précisions…">${esc(initial.note)}</textarea></label>
      <p class="form-msg" role="status"></p>
      <button class="btn primary block">${esc(submitLabel)}</button>
    </form>`);

  const msg = form.querySelector('.form-msg');
  const say = (text, err = false) => { msg.textContent = text; msg.classList.toggle('err', err); };
  const pv = form.querySelector('.pv');
  const removeBtn = form.querySelector('[data-remove-photo]');
  const drawPhoto = () => {
    pv.innerHTML = state.image ? `<img src="${esc(state.image)}" alt="" referrerpolicy="no-referrer">` : illus('gift');
    removeBtn.hidden = !state.image;
  };
  drawPhoto();
  removeBtn.addEventListener('click', () => { state.image = ''; drawPhoto(); });

  form.querySelector('input[type=file]').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    say('Envoi de la photo…');
    try {
      const { url } = await api('POST', '/api/upload', await shrinkImage(file));
      state.image = url; drawPhoto(); say('');
    } catch (err) { say(err.message, true); }
    e.target.value = '';
  });

  let lastFetched = initial.url || '';
  const fetchInfo = async () => {
    const url = form.url.value.trim();
    if (!/^https?:\/\//i.test(url) || url === lastFetched) return;
    lastFetched = url;
    say('Lecture de la page…');
    try {
      const p = await api('POST', '/api/preview', { url });
      // On remplace seulement ce qui est vide ou ce qui avait été rempli automatiquement
      const auto = (field, value) => {
        if (value && (!form[field].value || form[field].value === state.auto[field])) { form[field].value = value; state.auto[field] = value; }
      };
      auto('title', p.title);
      auto('price', p.price);
      if (p.image && (!state.image || state.image === state.auto.image)) { state.image = state.auto.image = p.image; drawPhoto(); }
      say(p.warning || (p.title ? '' : 'Infos introuvables : remplissez le titre à la main.'));
      if (p.warning) form.title.select();
    } catch (err) { say(err.message, true); }
  };
  form.querySelector('[data-fetch]').addEventListener('click', () => { lastFetched = ''; fetchInfo(); });
  form.url.addEventListener('paste', () => setTimeout(fetchInfo, 0));
  form.url.addEventListener('change', fetchInfo);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = form.title.value.trim();
    if (!title) { say('Le titre est obligatoire.', true); form.title.focus(); return; }
    const btn = form.querySelector('button.primary');
    btn.disabled = true;
    try {
      await onSave({ url: form.url.value.trim(), title, price: form.price.value.trim(), note: form.note.value.trim(), image: state.image });
    } catch (err) { say(err.message, true); }
    btn.disabled = false;
  });
  return form;
}

// Formulaire d'ajout avec choix de la liste (bouton +, bouton favori)
function addIdeaForm({ lists, preId, initial = {}, onDone }) {
  let sel = preId ? String(preId) : store.get('wl_last_list');
  if (!lists.some((l) => String(l.id) === sel)) sel = lists[0] ? String(lists[0].id) : 'new';
  const wrap = h(`
    <div class="form">
      <label class="field"><span>Dans la liste</span>
        <select>${lists.map((l) => `<option value="${l.id}" ${String(l.id) === sel ? 'selected' : ''}>${esc(l.title)}</option>`).join('')}
          <option value="new" ${sel === 'new' ? 'selected' : ''}>+ Nouvelle liste…</option></select></label>
      <label class="field" data-new ${sel === 'new' ? '' : 'hidden'}><span>Nom de la nouvelle liste</span>
        <input type="text" maxlength="120" placeholder="ex. Noël 2026"></label>
    </div>`);
  const $sel = wrap.querySelector('select');
  const $new = wrap.querySelector('[data-new]');
  const $newTitle = $new.querySelector('input');
  $sel.addEventListener('change', () => { $new.hidden = $sel.value !== 'new'; if (!$new.hidden) $newTitle.focus(); });
  wrap.append(itemForm(initial, {
    onSave: async (data) => {
      let listId = $sel.value;
      let listTitle = $sel.selectedOptions[0].textContent;
      if (listId === 'new') {
        listTitle = $newTitle.value.trim();
        if (!listTitle) { $newTitle.focus(); throw new Error('Donnez un nom à la nouvelle liste.'); }
        listId = (await api('POST', '/api/lists', { title: listTitle })).id;
      }
      await api('POST', `/api/lists/${listId}/items`, data);
      store.set('wl_last_list', String(listId));
      onDone(listId, listTitle, data);
    },
  }));
  return wrap;
}

async function openAddIdea(preId) {
  const lists = (await api('GET', '/api/lists')).filter((l) => l.is_owner);
  const s = openSheet({ title: 'Nouvelle idée' });
  s.body.append(addIdeaForm({
    lists, preId,
    onDone: (listId) => {
      closeSheet();
      toast('Idée ajoutée');
      if (location.pathname === `/list/${listId}`) route(); else go(`/list/${listId}`);
    },
  }));
}

// ============ Idées : carte, détail, réservation ============
// ctx = { list, own, hidden, guest, slug, onChange }
function canReserve(ctx) { return ctx.guest || !ctx.hidden; }

function itemCard(item, ctx) {
  const reserved = !!item.chosen;
  const el = h(`
    <div class="item ${reserved ? 'reserved' : ''}" role="button" tabindex="0" aria-label="${esc(item.title)}">
      <div class="thumb">
        ${item.image ? imgTag(item.image, item.title) : `<span class="placeholder">${illus('gift')}</span>`}
        <div class="status">${reserved ? `<span class="pill ok">${icon('check')} Réservé</span>` : ''}</div>
        ${canReserve(ctx) ? `<button class="check-btn ${reserved ? 'on' : ''}" aria-label="${reserved ? 'Réservé' : 'Réserver'}" title="${reserved ? 'Réservé' : 'Je réserve'}">${icon('check')}</button>` : ''}
      </div>
      <div class="info">
        <h3>${esc(item.title)}</h3>
        ${item.price ? `<span class="price">${esc(item.price)}</span>` : ''}
        ${reserved && item.chosen_by ? `<span class="by">par ${item.chosen_by_me ? 'vous' : esc(item.chosen_by)}</span>` : ''}
      </div>
    </div>`);
  el.addEventListener('click', (e) => {
    if (e.target.closest('.check-btn')) { e.stopPropagation(); toggleReserve(item, ctx); return; }
    openItem(item, ctx);
  });
  el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target === el) openItem(item, ctx); });
  return el;
}

async function askGuestName() {
  return new Promise((resolve) => {
    const s = openSheet({ title: 'Qui réserve ?' });
    const f = h(`<form class="form">
      <p class="muted">Indiquez votre prénom pour que les autres sachent qui offre ce cadeau (facultatif).</p>
      <input type="text" name="name" maxlength="60" placeholder="Votre prénom" value="${esc(store.get('wl_name'))}">
      <button class="btn primary block">${icon('check')} Je réserve ce cadeau</button></form>`);
    f.addEventListener('submit', (e) => { e.preventDefault(); store.set('wl_name', f.name.value.trim()); closeSheet(); resolve(f.name.value.trim()); });
    s.el.querySelector('[data-close]').addEventListener('click', () => resolve(null));
    s.body.append(f);
    setTimeout(() => f.name.focus(), 50);
  });
}

async function toggleReserve(item, ctx) {
  try {
    if (!item.chosen) {
      if (ctx.guest) {
        const name = await askGuestName();
        if (name === null) return;
        await api('POST', `/api/share/${ctx.slug}/items/${item.id}/choose`, { chosen: true, name });
      } else {
        await api('POST', `/api/items/${item.id}/choose`, { chosen: true });
      }
      toast('Cadeau réservé');
    } else {
      const mineOrGuest = ctx.guest ? !item.by_member : (item.chosen_by_me || !item.chosen_by_user);
      if (!mineOrGuest) { toast(`Déjà réservé par ${item.chosen_by || 'quelqu\'un'}`); return; }
      const ok = await confirmSheet({ title: 'Annuler la réservation ?', text: `« ${esc(item.title)} » redeviendra disponible pour les autres.`, ok: 'Annuler la réservation' });
      if (!ok) return;
      if (ctx.guest) await api('POST', `/api/share/${ctx.slug}/items/${item.id}/choose`, { chosen: false });
      else await api('POST', `/api/items/${item.id}/choose`, { chosen: false });
      toast('Réservation annulée');
    }
  } catch (err) { toast(err.message); }
  closeSheet();
  ctx.onChange();
}

function openItem(item, ctx) {
  const s = openSheet({ title: 'Idée de cadeau', wide: true });
  const reserved = !!item.chosen;
  const mine = ctx.guest ? reserved && !item.by_member : item.chosen_by_me || (reserved && !item.chosen_by_user);
  let status = '';
  if (ctx.hidden) status = `<div class="status-box">${icon('eyeOff')}<span>Mode surprise : vous ne saurez pas si cette idée est réservée.</span></div>`;
  else if (reserved) status = `<div class="status-box ok">${icon('check')}<span>Réservé${item.chosen_by ? ` par ${item.chosen_by_me ? 'vous' : esc(item.chosen_by)}` : ''}</span></div>`;
  else status = '<div class="status-box"><span class="dot"></span><span>Disponible : personne ne l\'a encore réservé.</span></div>';

  const d = h(`
    <div class="detail">
      <div class="pic">${item.image ? imgTag(item.image, item.title) : illus('gift')}</div>
      <div class="body">
        <div><span class="pill">${listIcon(ctx.list.emoji, 'xs')} ${esc(ctx.list.title)}</span></div>
        <h2>${esc(item.title)}</h2>
        ${item.price ? `<div class="price">${esc(item.price)}</div>` : ''}
        ${item.url ? `<a class="btn block" href="${esc(item.url)}" target="_blank" rel="noopener noreferrer">${icon('external')} Voir sur ${esc(hostOf(item.url))}</a>` : ''}
        ${item.note ? `<p class="note">${esc(item.note)}</p>` : ''}
        ${status}
        ${canReserve(ctx) && !reserved ? `<button class="btn primary block" data-reserve>${icon('check')} Je réserve ce cadeau</button>` : ''}
        ${canReserve(ctx) && reserved && mine ? '<button class="btn block" data-reserve>Annuler ma réservation</button>' : ''}
        ${ctx.own ? `<div style="display:flex;gap:8px">
          <button class="btn" style="flex:1" data-edit>${icon('edit')} Modifier</button>
          <button class="btn danger" style="flex:1" data-del>${icon('trash')} Supprimer</button></div>` : ''}
      </div>
    </div>`);
  d.querySelector('[data-reserve]')?.addEventListener('click', () => toggleReserve(item, ctx));
  d.querySelector('[data-edit]')?.addEventListener('click', () => {
    const e = openSheet({ title: 'Modifier l\'idée' });
    e.body.append(itemForm(item, {
      submitLabel: 'Enregistrer',
      onSave: async (data) => { await api('PATCH', `/api/items/${item.id}`, data); closeSheet(); toast('Idée modifiée'); ctx.onChange(); },
    }));
  });
  d.querySelector('[data-del]')?.addEventListener('click', async () => {
    if (!(await confirmSheet({ title: 'Supprimer cette idée ?', text: `« ${esc(item.title)} » sera supprimée de la liste.`, ok: 'Supprimer', danger: true }))) return;
    await api('DELETE', `/api/items/${item.id}`);
    toast('Idée supprimée');
    ctx.onChange();
  });
  s.body.append(d);
}

function renderItemsSection(container, items, ctx, filter = 'all') {
  const free = items.filter((i) => !i.chosen).length;
  const taken = items.length - free;
  const showFilters = !ctx.hidden && items.length > 0 && taken > 0;
  const shown = filter === 'free' ? items.filter((i) => !i.chosen) : filter === 'taken' ? items.filter((i) => i.chosen) : items;
  container.innerHTML = `
    ${showFilters ? `<div class="chips" style="margin-bottom:16px">
      <button class="chip ${filter === 'all' ? 'active' : ''}" data-f="all">Toutes <span class="count">${items.length}</span></button>
      <button class="chip ${filter === 'free' ? 'active' : ''}" data-f="free">Disponibles <span class="count">${free}</span></button>
      <button class="chip ${filter === 'taken' ? 'active' : ''}" data-f="taken">Réservées <span class="count">${taken}</span></button>
    </div>` : ''}
    <div class="items"></div>`;
  container.querySelectorAll('[data-f]').forEach((b) => b.addEventListener('click', () => renderItemsSection(container, items, ctx, b.dataset.f)));
  const grid = container.querySelector('.items');
  if (!items.length) {
    grid.outerHTML = emptyState('sparkles', ctx.own ? 'Cette liste est vide. Ajoutez une première idée : un lien, une photo ou juste un titre.' : 'Cette liste est encore vide.',
      ctx.own ? `<button class="btn primary" data-add-empty>${icon('plus')} Ajouter une idée</button>` : '');
    container.querySelector('[data-add-empty]')?.addEventListener('click', () => openAddIdea(ctx.list.id));
    return;
  }
  if (!shown.length) grid.outerHTML = emptyState('search', 'Rien ici pour le moment.');
  else shown.forEach((it) => grid.append(itemCard(it, ctx)));
}

function listHero(list, { own, guest }) {
  const date = list.event_date ? `<span class="pill">${icon('calendar')} ${esc(fmtDate(list.event_date))} · ${whenLabel(list.event_date)}</span>` : '';
  return `
    <section class="list-hero" style="${tint(list.id)}">
      <div class="row1">
        <div class="emoji-big">${listIcon(list.emoji)}</div>
        <div style="min-width:0">
          <h1 style="overflow-wrap:anywhere">${esc(list.title)}</h1>
          <div class="owner">${avatar(list.owner_name || '?')} ${own ? 'Ma liste' : `Liste ${deName(list.owner_name)}`}</div>
        </div>
      </div>
      ${list.description ? `<p class="desc">${esc(list.description)}</p>` : ''}
      <div style="display:flex;gap:6px;flex-wrap:wrap">
        ${date}
        <span class="pill">${plural(list.items.length, 'idée')}</span>
        ${own && list.surprise ? `<span class="pill">${icon('eyeOff')} Mode surprise</span>` : ''}
      </div>
      ${guest ? '' : `<div class="actions">
        ${own ? `<button class="btn primary" data-add>${icon('plus')} Ajouter une idée</button>` : ''}
        <button class="btn" data-share>${icon('share')} Partager</button>
        ${own ? `<button class="btn" data-edit-list>${icon('edit')} Modifier</button>` : ''}
      </div>`}
    </section>`;
}

// ============ Page d'une liste (membre connecté) ============
async function renderList(id) {
  const list = await api('GET', `/api/lists/${id}`);
  const own = list.is_owner;
  if (own) currentOwnList = list.id;
  document.title = `${list.title} – Wishlist`;
  $app.innerHTML = `
    <div class="page-head">
      <button class="icon-btn" id="back" aria-label="Retour">${icon('back')}</button>
      <span class="title">${own ? 'Ma liste' : esc(list.owner_name)}</span>
      <span style="width:42px"></span>
    </div>
    <div class="stack">
      ${listHero(list, { own })}
      <section id="items-section"></section>
    </div>`;
  document.getElementById('back').onclick = () => back('/');
  const ctx = { list, own, hidden: own && !!list.surprise, onChange: () => renderList(id) };
  renderItemsSection(document.getElementById('items-section'), list.items, ctx);
  $app.querySelector('[data-add]')?.addEventListener('click', () => openAddIdea(list.id));
  $app.querySelector('[data-edit-list]')?.addEventListener('click', () => openListForm(list));
  $app.querySelector('[data-share]')?.addEventListener('click', () => openShare(list));
}

function openShare(list) {
  const s = openSheet({ title: 'Partager la liste' });
  const url = `${location.origin}/l/${list.slug}`;
  s.body.append(h(`<div class="form">
    <p class="muted">Les membres de la famille voient déjà toutes les listes. Ce lien sert aux personnes <strong>sans compte</strong> (amis, collègues…) : elles pourront voir la liste et réserver un cadeau.</p>
    <div class="copy-box"><input type="text" readonly value="${esc(url)}"><button class="btn primary" data-copy>${icon('copy')} Copier</button></div>
    ${navigator.share ? `<button class="btn block" data-native>${icon('share')} Envoyer…</button>` : ''}
  </div>`));
  s.body.querySelector('[data-copy]').onclick = () => copyText(url);
  s.body.querySelector('[data-native]')?.addEventListener('click', () => navigator.share({ title: list.title, url }).catch(() => {}));
}

// ============ Famille ============
async function renderFamily() {
  document.title = 'Famille – Wishlist';
  const [members, { token }] = await Promise.all([api('GET', '/api/members'), api('GET', '/api/invite')]);
  const inviteUrl = `${location.origin}/join/${token}`;
  $app.innerHTML = `
    <div class="stack">
      <div><h1>La famille</h1><p class="muted" style="margin-top:6px">Chacun voit les listes des autres et peut réserver un cadeau.</p></div>
      <section class="hero-banner" style="background:linear-gradient(135deg,var(--tint-2),var(--tint-3))">
        <h2>Inviter quelqu'un</h2>
        <p>Envoyez ce lien : la personne choisit un nom et un mot de passe, et rejoint la famille.</p>
        <span class="big-emoji top" aria-hidden="true">${illus('mail')}</span>
        <div class="copy-box" style="margin-top:14px;max-width:560px">
          <input type="text" readonly value="${esc(inviteUrl)}" aria-label="Lien d'invitation" style="background:var(--surface)">
          <button class="btn primary" id="copy-invite">${icon('copy')} Copier</button>
        </div>
        <button class="link" id="reset-invite" style="margin-top:10px;font-size:.82rem">Générer un nouveau lien</button>
      </section>
      <section>
        <div class="section-head"><h2>Membres (${members.length})</h2></div>
        <div class="people">${members.map((m) => `
          <a class="person" href="/famille/${m.id}" data-link>
            ${avatar(m.name, 'md')}
            <div><h3>${esc(m.name)}${m.id === me.id ? ' <span class="pill accent">vous</span>' : ''}</h3>
              <p class="small muted">${m.list_count ? plural(m.list_count, 'liste') : 'Aucune liste pour l\'instant'}</p></div>
            ${icon('chevron')}
          </a>`).join('')}</div>
      </section>
    </div>`;
  document.getElementById('copy-invite').onclick = () => copyText(inviteUrl);
  document.getElementById('reset-invite').onclick = async () => {
    if (!(await confirmSheet({ title: 'Nouveau lien d\'invitation ?', text: 'L\'ancien lien ne fonctionnera plus. Les comptes déjà créés ne sont pas touchés.', ok: 'Générer' }))) return;
    await api('POST', '/api/invite/reset');
    toast('Nouveau lien généré');
    renderFamily();
  };
}

async function renderMember(id) {
  const [members, lists] = await Promise.all([api('GET', '/api/members'), api('GET', '/api/lists')]);
  const m = members.find((x) => x.id === id);
  if (!m) throw new Error('Membre introuvable');
  const theirs = lists.filter((l) => l.owner_id === id);
  document.title = `${m.name} – Wishlist`;
  $app.innerHTML = `
    <div class="page-head">
      <button class="icon-btn" id="back" aria-label="Retour">${icon('back')}</button>
      <span class="title">Famille</span><span style="width:42px"></span>
    </div>
    <div class="stack">
      <div style="display:grid;justify-items:center;gap:10px;text-align:center">
        ${avatar(m.name, 'lg')}
        <h1>${esc(m.name)}</h1>
        <p class="muted">${plural(theirs.length, 'liste')}</p>
      </div>
      ${theirs.length ? `<div class="list-grid">${theirs.map((l) => listCard(l)).join('')}</div>`
        : emptyState('sprout', `${m.id === me.id ? 'Vous n\'avez' : esc(m.name) + ' n\'a'} pas encore de liste.`)}
    </div>`;
  document.getElementById('back').onclick = () => back('/famille');
}

// ============ Mes réservations ============
async function renderReserved() {
  document.title = 'Mes réservations – Wishlist';
  const items = await api('GET', '/api/reserved');
  const groups = new Map();
  for (const i of items) {
    const k = i.owner_name || '?';
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(i);
  }
  $app.innerHTML = `
    <div class="stack">
      <div><h1>Mes réservations</h1><p class="muted" style="margin-top:6px">Les cadeaux que vous avez prévu d'offrir.</p></div>
      ${!items.length ? emptyState('gift','Vous n\'avez encore rien réservé.<br>Parcourez les listes de la famille et cochez un cadeau.', '<a class="btn primary" href="/" data-link>Voir les listes</a>') : ''}
      ${[...groups].map(([owner, list]) => `
        <section class="card">
          <div class="member-row">${avatar(owner, 'md')}<h3>Pour ${esc(owner)}</h3><span class="pill">${list.length}</span></div>
          <div class="rows">${list.map((i) => `
            <div class="row-item">
              <a class="mini" href="/list/${i.list_id}" data-link>${i.image ? imgTag(i.image) : illus('gift')}</a>
              <a href="/list/${i.list_id}" data-link style="flex:1;min-width:0">
                <h3>${esc(i.title)}</h3>
                <p class="small muted">${esc(i.list_title)}${i.price ? ' · ' + esc(i.price) : ''}</p></a>
              ${i.url ? `<a class="icon-btn sm" href="${esc(i.url)}" target="_blank" rel="noopener noreferrer" title="Voir sur ${esc(hostOf(i.url))}">${icon('external')}</a>` : ''}
              <button class="icon-btn sm" data-cancel="${i.id}" title="Annuler la réservation">${icon('x')}</button>
            </div>`).join('')}</div>
        </section>`).join('')}
    </div>`;
  $app.querySelectorAll('[data-cancel]').forEach((b) => b.addEventListener('click', async () => {
    const item = items.find((i) => i.id === Number(b.dataset.cancel));
    if (!(await confirmSheet({ title: 'Annuler la réservation ?', text: `« ${esc(item.title)} » redeviendra disponible.`, ok: 'Annuler la réservation' }))) return;
    await api('POST', `/api/items/${item.id}/choose`, { chosen: false });
    toast('Réservation annulée');
    renderReserved();
  }));
}

// ============ Profil ============
function renderProfile() {
  document.title = 'Profil – Wishlist';
  const since = new Date(me.created_at.replace(' ', 'T') + 'Z').toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
  $app.innerHTML = `
    <div class="stack" style="max-width:640px;margin:0 auto">
      <div style="display:grid;justify-items:center;gap:8px;text-align:center;padding-top:8px">
        ${avatar(me.name, 'lg')}
        <h1>${esc(me.name)}</h1>
        <p class="muted">Membre depuis ${esc(since)}</p>
      </div>

      <section class="card" style="display:grid;gap:14px">
        <div class="member-row" style="margin:0"><span class="icon-btn" style="background:var(--accent-soft);color:var(--accent);border:0">${icon('bookmark')}</span>
          <div style="flex:1"><h3>Bouton « + Wishlist »</h3><p class="small muted">Ajoutez un produit depuis n'importe quel site, en un clic.</p></div></div>
        <ol class="steps small">
          <li>Affichez la barre de favoris (<kbd>Ctrl</kbd>+<kbd>Maj</kbd>+<kbd>B</kbd>, ou <kbd>⌘</kbd>+<kbd>Maj</kbd>+<kbd>B</kbd> sur Mac).</li>
          <li><strong>Glissez ce bouton</strong> dans la barre : <a class="btn primary sm bm-btn" id="bookmarklet" style="margin-left:4px">+ Wishlist</a></li>
          <li>Sur la page d'un produit, cliquez sur le favori : titre, photo et prix sont repris automatiquement.</li>
        </ol>
      </section>

      <form class="card form" id="pwd">
        <div class="member-row" style="margin:0"><span class="icon-btn" style="background:var(--surface-2);border:0">${icon('lock')}</span><h3>Changer de mot de passe</h3></div>
        <input type="password" name="current" placeholder="Mot de passe actuel" autocomplete="current-password" required>
        <input type="password" name="next" placeholder="Nouveau mot de passe (6 caractères min.)" autocomplete="new-password" minlength="6" required>
        <p class="form-msg err"></p>
        <button class="btn">Mettre à jour</button>
      </form>

      <button class="btn danger block" id="logout">${icon('logout')} Se déconnecter</button>
    </div>`;

  const bm = document.getElementById('bookmarklet');
  bm.href = bookmarkletHref();
  bm.title = 'Glissez-moi dans la barre de favoris';
  bm.addEventListener('click', (e) => { e.preventDefault(); toast('Glissez ce bouton dans votre barre de favoris'); });

  const f = document.getElementById('pwd');
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api('POST', '/api/password', { current: f.current.value, next: f.next.value });
      f.reset(); f.querySelector('.form-msg').textContent = '';
      toast('Mot de passe modifié');
    } catch (err) { f.querySelector('.form-msg').textContent = err.message; }
  });
  document.getElementById('logout').onclick = async () => {
    await api('POST', '/api/logout');
    me = null; navDepth = 0;
    history.replaceState(null, '', '/'); route();
  };
}

// ============ Bouton favori « + Wishlist » ============
// Ce code s'exécute sur la page du produit, dans le navigateur de l'utilisateur :
// il lit le titre, la photo et le prix, puis ouvre la page /add de l'appli pré-remplie.
function bookmarkletHref() {
  const code = `(function(){
var d=document,O=${JSON.stringify(location.origin)};
var m=function(k){var e=d.querySelector('meta[property="'+k+'"],meta[name="'+k+'"],meta[itemprop="'+k+'"]');return e&&e.content?e.content.trim():''};
var t=m('og:title')||m('twitter:title'),i=m('og:image')||m('og:image:url')||m('twitter:image'),p='';
var a=m('product:price:amount')||m('og:price:amount')||m('price'),c=m('product:price:currency')||m('og:price:currency')||m('priceCurrency');
if(a)p=a+' '+c;
try{d.querySelectorAll('script[type="application/ld+json"]').forEach(function(s){var q=[].concat(JSON.parse(s.textContent));while(q.length){var n=q.shift();if(!n||typeof n!='object')continue;if(n['@graph'])q=q.concat(n['@graph']);if([].concat(n['@type']).indexOf('Product')>-1){t=t||n.name||'';var im=[].concat(n.image||[])[0];i=i||(typeof im=='string'?im:(im&&im.url)||'');var o=[].concat(n.offers||[])[0]||{};var pr=o.price!=null?o.price:o.lowPrice;if(!p&&pr!=null)p=pr+' '+(o.priceCurrency||'')}}})}catch(e){}
if(!i){var b=0;d.querySelectorAll('img').forEach(function(x){var s=x.naturalWidth*x.naturalHeight;if(s>b&&x.currentSrc&&x.currentSrc.indexOf('data:')!==0){b=s;i=x.currentSrc}})}
try{i=i?new URL(i,location.href).href:''}catch(e){i=''}
var u=O+'/add?'+new URLSearchParams({url:location.href,title:(t||d.title||'').trim().slice(0,300),image:i.slice(0,2000),price:p.trim().slice(0,50)});
if(!window.open(u,'_blank'))location.href=u;
})()`;
  return 'javascript:' + encodeURIComponent(code.replace(/\n/g, ''));
}

// ============ Ajout rapide (depuis le bouton favori) ============
async function renderQuickAdd() {
  document.title = 'Ajouter – Wishlist';
  const params = new URLSearchParams(location.search);
  const initial = { url: params.get('url') || '', title: params.get('title') || '', image: params.get('image') || '', price: params.get('price') || '', note: '' };
  const lists = (await api('GET', '/api/lists')).filter((l) => l.is_owner);
  $app.innerHTML = `
    <div class="stack" style="max-width:600px;margin:0 auto">
      <div><h1>Nouvelle idée</h1>${initial.url ? `<p class="muted" style="margin-top:6px">depuis ${esc(hostOf(initial.url))}</p>` : ''}</div>
      <section class="card" id="qa"></section>
    </div>`;
  document.getElementById('qa').append(addIdeaForm({
    lists, initial,
    onDone: (listId, listTitle, data) => {
      history.replaceState(null, '', '/add');
      $app.innerHTML = `
        <div class="card" style="max-width:440px;margin:6vh auto 0;display:grid;gap:16px;justify-items:center;text-align:center;padding:32px">
          ${illus('party', 'xl')}
          <h1>C'est ajouté !</h1>
          <p class="muted">« ${esc(data.title)} » est maintenant dans <strong>${esc(listTitle)}</strong>.</p>
          <div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center">
            <a class="btn primary" href="/list/${listId}" data-link>Voir la liste</a>
            <button class="btn" id="close">Fermer l'onglet</button>
          </div>
        </div>`;
      document.getElementById('close').onclick = () => { window.close(); setTimeout(() => toast('Vous pouvez fermer cet onglet.'), 200); };
    },
  }));
}

// ============ Vue invité (lien de partage, sans compte) ============
async function renderShare(slug, filter = 'all') {
  renderChrome('guest');
  const list = await api('GET', `/api/share/${slug}`);
  document.title = `${list.title} – Wishlist`;
  const free = list.items.filter((i) => !i.chosen).length;
  $app.innerHTML = `
    <div class="stack">
      ${listHero(list, { guest: true })}
      <div class="status-box" style="background:var(--accent-soft)">${illus('gift', 'sm')}<span>Quand vous choisissez un cadeau, <strong>cochez-le</strong> pour que personne d'autre ne l'offre en double. ${plural(free, 'idée encore disponible', 'idées encore disponibles')}.</span></div>
      <section id="items-section"></section>
    </div>`;
  const ctx = { list, guest: true, slug, onChange: () => renderShare(slug) };
  renderItemsSection(document.getElementById('items-section'), list.items, ctx, filter);
}

route();
