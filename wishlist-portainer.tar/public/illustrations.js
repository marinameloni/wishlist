'use strict';
/* Illustrations SVG en couleur (style plat, palette pastel de l'appli).
   Toutes sur une grille 48×48. Utilisation : illus('cake', 'lg') */

const C = {
  coral: '#F0645A', coral2: '#FF8A7A', peach: '#FFB89A', peach2: '#FFD9C7',
  yellow: '#FFD166', yellow2: '#FFC145', mint: '#6CCFA5', mint2: '#43B88A', mint3: '#2FA67A',
  lav: '#A99BF0', lav2: '#C9B6F5', sky: '#7DB8F2', sky2: '#BDE0FA', sky3: '#5A9FE6',
  brown: '#B9774F', tan: '#D9A178', tan2: '#F2D3B8', cream: '#FFF8F2', ink: '#3A2E4F', ink2: '#544770',
};

const ILLUS = {
  // ---------- Icônes de listes ----------
  gift: `
    <ellipse cx="24" cy="44" rx="15" ry="2" fill="#000" opacity=".07"/>
    <rect x="8" y="20" width="32" height="22" rx="4" fill="${C.coral}"/>
    <rect x="8" y="22" width="32" height="3" fill="#000" opacity=".08"/>
    <rect x="6" y="14" width="36" height="9" rx="3" fill="${C.coral2}"/>
    <rect x="21" y="14" width="6" height="28" fill="${C.yellow}"/>
    <path d="M24 14c-3-6.5-11-8.5-12.3-3.4-.9 4 6.3 4.4 12.3 3.4z" fill="${C.yellow}"/>
    <path d="M24 14c3-6.5 11-8.5 12.3-3.4.9 4-6.3 4.4-12.3 3.4z" fill="${C.yellow2}"/>
    <path d="M11 17h6" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity=".55"/>`,
  tree: `
    <ellipse cx="24" cy="44.5" rx="13" ry="1.8" fill="#000" opacity=".07"/>
    <rect x="21" y="36" width="6" height="8" rx="1.5" fill="${C.brown}"/>
    <path d="M24 9 14 21h20z" fill="${C.mint}"/>
    <path d="M24 15 11 29h26z" fill="${C.mint2}"/>
    <path d="M24 22 8 38h32z" fill="${C.mint3}"/>
    <circle cx="19" cy="25" r="2" fill="${C.coral}"/><circle cx="29" cy="31" r="2" fill="${C.yellow}"/>
    <circle cx="17" cy="34" r="1.8" fill="${C.sky2}"/><circle cx="27" cy="19" r="1.6" fill="${C.yellow}"/>
    <path d="m24 2 1.6 3.3 3.6.5-2.6 2.5.6 3.6L24 10.2l-3.2 1.7.6-3.6-2.6-2.5 3.6-.5z" fill="${C.yellow2}"/>`,
  cake: `
    <rect x="6" y="39" width="36" height="4" rx="2" fill="#E9DED5"/>
    <rect x="9" y="24" width="30" height="16" rx="4" fill="${C.peach}"/>
    <path d="M9 28c3 3.4 6 3.4 7.5 0s4.5-3.4 7.5 0 6 3.4 7.5 0 4.5-3.4 7.5 0v-.5A4 4 0 0 0 35 23.5H13a4 4 0 0 0-4 4z" fill="${C.cream}"/>
    <rect x="13.5" y="33" width="3" height="1.6" rx=".8" fill="${C.lav}" transform="rotate(-25 15 34)"/>
    <rect x="23" y="35" width="3" height="1.6" rx=".8" fill="${C.sky}" transform="rotate(20 24.5 36)"/>
    <rect x="31" y="32.5" width="3" height="1.6" rx=".8" fill="${C.mint}" transform="rotate(-15 32.5 33)"/>
    <rect x="17" y="13" width="3.2" height="11" rx="1.6" fill="${C.lav}"/>
    <rect x="27.8" y="13" width="3.2" height="11" rx="1.6" fill="${C.sky}"/>
    <path d="M18.6 6c2.4 2.8 2.4 4.8 0 6-2.4-1.2-2.4-3.2 0-6z" fill="${C.yellow2}"/>
    <path d="M29.4 6c2.4 2.8 2.4 4.8 0 6-2.4-1.2-2.4-3.2 0-6z" fill="${C.yellow2}"/>`,
  ring: `
    <ellipse cx="24" cy="44.5" rx="11" ry="1.6" fill="#000" opacity=".07"/>
    <circle cx="24" cy="30" r="11.5" fill="none" stroke="${C.yellow2}" stroke-width="4.5"/>
    <path d="M14.5 26a10.5 10.5 0 0 1 6-6.5" stroke="#fff" stroke-width="1.8" stroke-linecap="round" fill="none" opacity=".7"/>
    <path d="m17 12 3.5-6h7l3.5 6-7 8z" fill="${C.sky2}"/>
    <path d="M17 12h14l-7 8z" fill="${C.sky}"/>
    <path d="m20.5 6 3.5 6 3.5-6" stroke="#fff" stroke-width="1.2" fill="none" opacity=".8"/>`,
  baby: `
    <ellipse cx="24" cy="45" rx="10" ry="1.6" fill="#000" opacity=".07"/>
    <rect x="15" y="17" width="18" height="27" rx="7" fill="${C.sky2}"/>
    <path d="M15 29h18v8a7 7 0 0 1-7 7h-4a7 7 0 0 1-7-7z" fill="#fff"/>
    <path d="M28 22h3M28 26h3M28 30h3" stroke="${C.sky3}" stroke-width="1.6" stroke-linecap="round"/>
    <rect x="13" y="13" width="22" height="6" rx="3" fill="${C.sky}"/>
    <path d="M20 13c0-5.5 1.8-9 4-9s4 3.5 4 9z" fill="${C.peach}"/>`,
  cap: `
    <path d="M12 23v8.5c0 3.4 5.4 6.5 12 6.5s12-3.1 12-6.5V23l-12 5.4z" fill="${C.ink2}"/>
    <path d="M24 9 3.5 18.5 24 28l20.5-9.5z" fill="${C.ink}"/>
    <path d="M24 18.5 38 21v11" stroke="${C.yellow2}" stroke-width="2" fill="none" stroke-linecap="round"/>
    <path d="M36 32h4l1 6h-6z" fill="${C.yellow2}"/>
    <circle cx="24" cy="18.5" r="2" fill="${C.yellow}"/>`,
  house: `
    <ellipse cx="24" cy="44.5" rx="16" ry="1.6" fill="#000" opacity=".07"/>
    <path d="M9 22 24 9l15 13v18a3 3 0 0 1-3 3H12a3 3 0 0 1-3-3z" fill="${C.peach2}"/>
    <path d="M5.5 23.5 24 7l18.5 16.5" fill="none" stroke="${C.coral}" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
    <rect x="31" y="9" width="5" height="9" rx="1" fill="${C.coral}"/>
    <rect x="20" y="29" width="8" height="14" rx="2" fill="${C.brown}"/>
    <circle cx="26" cy="36.5" r=".9" fill="${C.yellow}"/>
    <rect x="13" y="25" width="5.5" height="5.5" rx="1.2" fill="${C.sky2}"/>
    <rect x="30" y="25" width="5.5" height="5.5" rx="1.2" fill="${C.sky2}"/>`,
  plane: `
    <path d="M4 22 44 6 35 41 22 31z" fill="${C.sky}"/>
    <path d="M22 31 44 6 17.5 27.5z" fill="${C.sky3}"/>
    <path d="m17.5 27.5 4.5 3.5-3 9.5z" fill="#3F86D4"/>
    <path d="M6 36c4 0 6-2 8-4M3 30c3 0 4-1 5.5-2" stroke="${C.lav}" stroke-width="2" stroke-linecap="round" stroke-dasharray="1 3.5" fill="none"/>`,
  heart: `
    <ellipse cx="24" cy="45" rx="12" ry="1.6" fill="#000" opacity=".07"/>
    <path d="M24 41.5S6 30.8 6 18.5a9 9 0 0 1 18-3.2 9 9 0 0 1 18 3.2C42 30.8 24 41.5 24 41.5z" fill="${C.coral}"/>
    <path d="M11.5 17.5a5.5 5.5 0 0 1 5.5-5.5" stroke="#fff" stroke-width="2.6" stroke-linecap="round" fill="none" opacity=".6"/>
    <circle cx="35.5" cy="11" r="2" fill="${C.yellow}"/><circle cx="40.5" cy="6.5" r="1.2" fill="${C.lav}"/>`,
  egg: `
    <ellipse cx="24" cy="44.5" rx="11" ry="1.6" fill="#000" opacity=".07"/>
    <path d="M24 5c7.5 0 13.5 12 13.5 22.5S31.5 44 24 44s-13.5-6-13.5-16.5S16.5 5 24 5z" fill="${C.lav2}"/>
    <path d="M11 25l4.4 3.4 4.3-3.4 4.3 3.4 4.3-3.4 4.3 3.4 4.4-3.4" stroke="#fff" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
    <circle cx="18" cy="16" r="1.8" fill="${C.yellow}"/><circle cx="28" cy="13" r="1.5" fill="${C.coral2}"/>
    <circle cx="20" cy="36" r="1.8" fill="${C.mint}"/><circle cx="30" cy="35" r="1.6" fill="${C.yellow}"/>`,
  flower: `
    <path d="M24 26v18" stroke="${C.mint2}" stroke-width="3" stroke-linecap="round"/>
    <path d="M24 38c-6 0-9-4-9-7 5 0 9 2 9 7z" fill="${C.mint}"/>
    <g fill="#FFB3C7">
      <circle cx="24" cy="10" r="6.5"/><circle cx="32.5" cy="16" r="6.5"/><circle cx="29.5" cy="25.5" r="6.5"/>
      <circle cx="18.5" cy="25.5" r="6.5"/><circle cx="15.5" cy="16" r="6.5"/>
    </g>
    <circle cx="24" cy="18" r="5" fill="${C.yellow}"/>
    <circle cx="22.5" cy="16.5" r="1.4" fill="#fff" opacity=".7"/>`,
  party: `
    <path d="M7 43 15.5 17 31 32.5z" fill="${C.yellow2}"/>
    <path d="m11 30.5 9.5 9.6M13.4 23.4l13.4 13.3" stroke="${C.coral}" stroke-width="2.6"/>
    <path d="M7 43 15.5 17 18 19.5 10 43.8z" fill="#000" opacity=".06"/>
    <path d="M24 13c3-3 2-6 5-8M30 20c3-1 5 1 8-1M34 10l3-3" stroke="${C.lav}" stroke-width="2.4" stroke-linecap="round" fill="none"/>
    <circle cx="38" cy="27" r="2" fill="${C.mint}"/><circle cx="22" cy="6" r="1.8" fill="${C.coral}"/>
    <rect x="40" y="13" width="3.5" height="3.5" rx=".8" fill="${C.sky}" transform="rotate(20 41.7 14.7)"/>
    <rect x="27" y="23" width="3" height="3" rx=".7" fill="${C.yellow}" transform="rotate(-25 28.5 24.5)"/>`,
  book: `
    <ellipse cx="24" cy="44.5" rx="16" ry="1.6" fill="#000" opacity=".07"/>
    <path d="M5 12.5c6.5-2.2 13-1.2 19 3V42c-6-4-12.5-5-19-3z" fill="${C.sky}"/>
    <path d="M43 12.5c-6.5-2.2-13-1.2-19 3V42c6-4 12.5-5 19-3z" fill="${C.lav}"/>
    <path d="M9 19c3.5-.8 7-.4 11 1.5M9 25c3.5-.8 7-.4 11 1.5M28 20.5c4-1.9 7.5-2.3 11-1.5M28 26.5c4-1.9 7.5-2.3 11-1.5" stroke="#fff" stroke-width="1.8" stroke-linecap="round" opacity=".7"/>
    <path d="M33 10v12l2.5-2 2.5 2V9.5" fill="${C.coral}"/>`,
  teddy: `
    <ellipse cx="24" cy="45" rx="13" ry="1.6" fill="#000" opacity=".07"/>
    <circle cx="12" cy="11" r="6" fill="${C.tan}"/><circle cx="36" cy="11" r="6" fill="${C.tan}"/>
    <circle cx="12" cy="11" r="3" fill="${C.tan2}"/><circle cx="36" cy="11" r="3" fill="${C.tan2}"/>
    <circle cx="24" cy="25" r="16" fill="${C.tan}"/>
    <ellipse cx="24" cy="31" rx="8" ry="6.5" fill="${C.tan2}"/>
    <circle cx="18" cy="22" r="2" fill="${C.ink}"/><circle cx="30" cy="22" r="2" fill="${C.ink}"/>
    <ellipse cx="24" cy="28.5" rx="3" ry="2.2" fill="${C.ink}"/>
    <path d="M24 31v2.5M21.5 34c1.4 1 3.6 1 5 0" stroke="${C.ink}" stroke-width="1.5" stroke-linecap="round" fill="none"/>
    <circle cx="13.5" cy="29" r="2.5" fill="#F7A6A0" opacity=".6"/><circle cx="34.5" cy="29" r="2.5" fill="#F7A6A0" opacity=".6"/>`,

  // ---------- Illustrations ----------
  mail: `
    <rect x="5" y="13" width="38" height="27" rx="4" fill="#fff"/>
    <path d="M5 17 24 30 43 17" stroke="${C.lav2}" stroke-width="2.5" fill="none" stroke-linejoin="round"/>
    <rect x="5" y="13" width="38" height="27" rx="4" fill="none" stroke="${C.lav2}" stroke-width="2"/>
    <path d="M33 5.5c2-3 6.5-1.5 5.5 2-.6 2.4-5.5 5.5-5.5 5.5s-4.9-3.1-5.5-5.5c-1-3.5 3.5-5 5.5-2z" fill="${C.coral}"/>`,
  family: `
    <circle cx="13" cy="15" r="6" fill="${C.peach}"/>
    <path d="M3 41a10 10 0 0 1 20 0z" fill="${C.coral}"/>
    <circle cx="35" cy="15" r="6" fill="${C.tan}"/>
    <path d="M25 41a10 10 0 0 1 20 0z" fill="${C.sky}"/>
    <circle cx="24" cy="25.5" r="4.5" fill="${C.peach2}"/>
    <path d="M16.5 43a7.5 7.5 0 0 1 15 0z" fill="${C.yellow}"/>
    <path d="M24 9.5c1-1.6 3.6-.8 3 1-.4 1.2-3 2.8-3 2.8s-2.6-1.6-3-2.8c-.6-1.8 2-2.6 3-1z" fill="${C.coral}"/>`,
  sparkles: `
    <path d="M20 5c1.6 8.4 4.2 11 12.6 12.6C24.2 19.2 21.6 21.8 20 30.2 18.4 21.8 15.8 19.2 7.4 17.6 15.8 16 18.4 13.4 20 5z" fill="${C.yellow}"/>
    <path d="M36 25c.9 4.4 2.2 5.7 6.6 6.6-4.4.9-5.7 2.2-6.6 6.6-.9-4.4-2.2-5.7-6.6-6.6 4.4-.9 5.7-2.2 6.6-6.6z" fill="${C.lav}"/>
    <path d="M12 31c.7 3.2 1.6 4.1 4.8 4.8-3.2.7-4.1 1.6-4.8 4.8-.7-3.2-1.6-4.1-4.8-4.8 3.2-.7 4.1-1.6 4.8-4.8z" fill="${C.coral}"/>`,
  sprout: `
    <path d="M14 30h20l-3 13H17z" fill="#F0A07A"/>
    <rect x="12" y="27" width="24" height="5" rx="2" fill="#E8875F"/>
    <path d="M24 28V16" stroke="${C.mint2}" stroke-width="3" stroke-linecap="round"/>
    <path d="M24 20c-8 0-11.5-5-11.5-9.5 6.5 0 11.5 3.5 11.5 9.5z" fill="${C.mint}"/>
    <path d="M24 16.5c0-6.5 4-9.5 10.5-9.5 0 5.5-3.5 9.5-10.5 9.5z" fill="${C.mint2}"/>`,
  search: `
    <circle cx="21" cy="21" r="12.5" fill="${C.sky2}" stroke="${C.sky}" stroke-width="4"/>
    <path d="M30.5 30.5 41 41" stroke="${C.ink}" stroke-width="5.5" stroke-linecap="round"/>
    <path d="M14.5 18.5a7 7 0 0 1 6.5-5" stroke="#fff" stroke-width="2.6" stroke-linecap="round" fill="none"/>`,
  check: `
    <circle cx="24" cy="24" r="19" fill="${C.mint}"/>
    <path d="m15 24.5 6 6 12-13" stroke="#fff" stroke-width="4.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,
};

// Icônes proposées pour une liste (ordre du sélecteur)
const LIST_ICONS = ['gift', 'tree', 'cake', 'ring', 'baby', 'cap', 'house', 'plane', 'heart', 'egg', 'flower', 'party', 'book', 'teddy'];
const LIST_ICON_LABELS = {
  gift: 'Cadeau', tree: 'Noël', cake: 'Anniversaire', ring: 'Mariage', baby: 'Naissance', cap: 'Diplôme', house: 'Maison',
  plane: 'Voyage', heart: 'Amour', egg: 'Pâques', flower: 'Fleur', party: 'Fête', book: 'Lecture', teddy: 'Enfant',
};

function illus(key, cls = '') {
  const body = ILLUS[key] || ILLUS.gift;
  return `<svg class="ill ${cls}" viewBox="0 0 48 48" aria-hidden="true" focusable="false">${body}</svg>`;
}
const listIcon = (key, cls = '') => illus(LIST_ICONS.includes(key) ? key : 'gift', cls);
